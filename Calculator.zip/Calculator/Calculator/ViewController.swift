//
//  ViewController.swift
//  Calculator
//
//  Created by Z Ali on 2/27/22.
//

import UIKit

class ViewController: UIViewController {
    //setting up variables
    var doubleFormula: Double = 0;
    var previousNumber: Double = 0;
    var signs = false
    var operation = 0
    //setting up constants
    @IBOutlet weak var formula: UILabel!
    
    //logic for getting number values
    @IBAction func numbers(_ sender: UIButton) {
        if signs == true{
            formula.text = String(sender.tag)
            doubleFormula = Double(formula.text!)!
            signs = false
        }else{
            formula.text = formula.text! + String(sender.tag)
            doubleFormula = Double(formula.text!)!
        }
    }
    
    //logic to handle nonNumbers such as calcultion signs
    @IBAction func nonNumbers(_ sender: UIButton) {
        if formula.text != "" && sender.tag != 10 && sender.tag != 15{
            previousNumber = Double(formula.text!)!
            if sender.tag == 11 {
                formula.text = "/"
            }
            else if sender.tag == 12{
                formula.text = "X"
            }
            else if sender.tag == 13{
                formula.text = "-"
            }
            else if sender.tag == 14{
                formula.text = "+"
            }
            operation = sender.tag
            signs = true
        }
        else if sender.tag == 15 { //logic for hitting equal signs
            if operation == 11{
                formula.text = String(previousNumber / doubleFormula)
            }
            else if operation == 12{
                formula.text = String(previousNumber * doubleFormula)
            }
            else if operation == 13{
                formula.text = String(previousNumber - doubleFormula)
            }
            else if operation == 14{
                formula.text = String(previousNumber + doubleFormula)
            }
        }
        else if sender.tag == 10{  //logic for hitting clear
            doubleFormula = 0
            previousNumber = 0
            signs = false
            operation = 0
            formula.text = ""
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}

